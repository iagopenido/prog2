class vehicle {
  int license;
  String brand;
  int year;

  vehicle(this.license, this.brand, this.year);

  void show() {
    print("License: $license, brand: $brand, year: $year");
  }
}
