import 'package:exame_final/vehicle.dart';

class motocycle extends vehicle {
  int capacity;

  motocycle(super.license, super.brand, super.year, this.capacity);
  @override
  void show() {
    print("License: $license, brand: $brand, year: $year, Capacity: $capacity");
  }
}
