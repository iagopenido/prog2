import 'package:exame_final/vehicle.dart';

class car extends vehicle {
  int doors;

  car(super.license, super.brand, super.year, this.doors);
  @override
  void show() {
    print("License: $license, brand: $brand, year: $year, Doors: $doors");
  }
}
