import 'Media.dart';
import 'dart:convert';
import 'dart:async' show Future;

class DigitalLibrary {
  final List<Media> _media = [];

  void addMedia(Media media) {
    _media.add(media);
  }

  void loadMedia() {
    Future<String> 
  }
}