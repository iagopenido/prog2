
abstract class Media {
  final String type;
  final String title;
  final int duration;

  Media(this.type, this.title, this.duration);
  
  String get name;
}
